// api/extract.js — Vercel serverless function
// Anthropic API key stays server-side. Never exposed to browser.
// Implements prompt caching on system prompt (90% cost reduction on repeats).
// Rate limited: max 10 extraction requests per IP per hour.

const RATE_LIMIT_MAP = new Map(); // In-memory; use Upstash Redis in production
const RATE_LIMIT_MAX = 10;
const RATE_LIMIT_WINDOW_MS = 60 * 60 * 1000; // 1 hour

function getRateLimit(ip) {
  const now = Date.now();
  const entry = RATE_LIMIT_MAP.get(ip);
  if (!entry || now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
    RATE_LIMIT_MAP.set(ip, { count: 1, windowStart: now });
    return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
  }
  if (entry.count >= RATE_LIMIT_MAX) {
    return { allowed: false, remaining: 0 };
  }
  entry.count++;
  return { allowed: true, remaining: RATE_LIMIT_MAX - entry.count };
}

export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN || '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ message: 'Method not allowed' });

  // Rate limit
  const ip = req.headers['x-forwarded-for']?.split(',')[0] || req.socket?.remoteAddress || 'unknown';
  const { allowed, remaining } = getRateLimit(ip);
  res.setHeader('X-RateLimit-Remaining', remaining);
  if (!allowed) {
    return res.status(429).json({ message: 'Too many extraction requests. Please try again later.' });
  }

  const { system, prompt, fileBase64, mimeType } = req.body || {};

  if (!prompt || !fileBase64 || !mimeType) {
    return res.status(400).json({ message: 'Missing required fields: prompt, fileBase64, mimeType' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ message: 'Server configuration error' });
  }

  // Validate file size (max 10MB base64 ≈ 7.5MB file)
  if (fileBase64.length > 10 * 1024 * 1024) {
    return res.status(400).json({ message: 'File too large. Maximum 7.5MB.' });
  }

  // Validate mime type
  const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
  if (!allowedTypes.includes(mimeType)) {
    return res.status(400).json({ message: 'Unsupported file type.' });
  }

  try {
    const anthropicPayload = {
      model: 'claude-sonnet-4-6',
      max_tokens: 2048,
      system: [
        {
          type: 'text',
          text: system || 'You are an Indian income tax document extraction engine. Return only valid JSON.',
          // Prompt caching: system prompt cached for 5 minutes
          // After first call, repeated input costs 10% of standard price
          cache_control: { type: 'ephemeral' },
        },
      ],
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'document',
              source: {
                type: 'base64',
                media_type: mimeType,
                data: fileBase64,
              },
            },
            {
              type: 'text',
              text: prompt,
            },
          ],
        },
      ],
    };

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-beta': 'prompt-caching-2024-07-31',
      },
      body: JSON.stringify(anthropicPayload),
    });

    if (!response.ok) {
      const errBody = await response.json().catch(() => ({}));
      console.error('Anthropic API error:', response.status, errBody);
      return res.status(502).json({
        message: 'AI extraction service error. Please try again.',
        detail: process.env.NODE_ENV === 'development' ? errBody : undefined,
      });
    }

    const data = await response.json();
    const textBlock = data.content?.find(b => b.type === 'text');

    if (!textBlock?.text) {
      return res.status(502).json({ message: 'Empty response from AI service.' });
    }

    // Log cache usage for cost monitoring (visible in Vercel logs)
    const usage = data.usage || {};
    console.log('Extraction usage:', {
      input_tokens: usage.input_tokens,
      output_tokens: usage.output_tokens,
      cache_creation_input_tokens: usage.cache_creation_input_tokens,
      cache_read_input_tokens: usage.cache_read_input_tokens,
      model: data.model,
    });

    return res.status(200).json({ content: textBlock.text });
  } catch (err) {
    console.error('Extract handler error:', err);
    return res.status(500).json({ message: 'Internal server error during extraction.' });
  }
}
