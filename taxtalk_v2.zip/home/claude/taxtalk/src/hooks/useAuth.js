import { useState, useEffect, useCallback } from 'react';
import {
  supabase, signInWithOTP, verifyOTP, signOut as sbSignOut,
  getProfile, logAudit,
} from '../lib/supabase.js';

export function useAuth() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Load initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) loadProfile(session.user.id);
      else setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session?.user) loadProfile(session.user.id);
      else { setProfile(null); setLoading(false); }
    });

    return () => subscription.unsubscribe();
  }, []);

  async function loadProfile(userId) {
    try {
      const p = await getProfile(userId);
      setProfile(p);
    } catch (e) {
      console.error('loadProfile error:', e);
    } finally {
      setLoading(false);
    }
  }

  const sendOTP = useCallback(async (phone) => {
    setError(null);
    try {
      // Normalise: ensure +91 prefix
      const normalised = phone.startsWith('+') ? phone : `+91${phone.replace(/\D/g, '')}`;
      await signInWithOTP(normalised);
      return normalised;
    } catch (e) {
      setError(e.message);
      throw e;
    }
  }, []);

  const confirmOTP = useCallback(async (phone, token) => {
    setError(null);
    try {
      const data = await verifyOTP(phone, token);
      return data;
    } catch (e) {
      setError(e.message);
      throw e;
    }
  }, []);

  const signOut = useCallback(async () => {
    if (session?.user && profile?.id) {
      await logAudit(null, profile.id, 'sign_out').catch(() => {});
    }
    await sbSignOut();
    setProfile(null);
    setSession(null);
  }, [session, profile]);

  const isCA = profile?.role === 'ca_staff' || profile?.role === 'ca_admin';
  const isAdmin = profile?.role === 'ca_admin';

  return {
    session,
    user: session?.user ?? null,
    profile,
    loading,
    error,
    isCA,
    isAdmin,
    sendOTP,
    confirmOTP,
    signOut,
    refreshProfile: () => session?.user && loadProfile(session.user.id),
  };
}
