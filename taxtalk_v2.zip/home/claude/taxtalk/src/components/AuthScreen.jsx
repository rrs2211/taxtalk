import React, { useState } from 'react';
import { Phone, Shield, ArrowRight, RotateCcw } from 'lucide-react';

const STAGE = { PHONE: 'phone', OTP: 'otp', ERROR: 'error' };

export default function AuthScreen({ onAuth }) {
  const [stage, setStage] = useState(STAGE.PHONE);
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [normalisedPhone, setNormalisedPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const otpRefs = Array.from({ length: 6 }, () => React.useRef(null));

  async function handleSendOTP(e) {
    e.preventDefault();
    setError('');
    const digits = phone.replace(/\D/g, '');
    if (digits.length !== 10) {
      setError('Please enter a valid 10-digit mobile number');
      return;
    }
    setLoading(true);
    try {
      await onAuth.sendOTP(digits);
      setNormalisedPhone(`+91${digits}`);
      setStage(STAGE.OTP);
    } catch (err) {
      setError(err.message || 'Could not send OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function handleOTPChange(idx, val) {
    if (!/^\d*$/.test(val)) return;
    const next = [...otp];
    next[idx] = val.slice(-1);
    setOtp(next);
    if (val && idx < 5) otpRefs[idx + 1].current?.focus();
  }

  function handleOTPKeyDown(idx, e) {
    if (e.key === 'Backspace' && !otp[idx] && idx > 0) {
      otpRefs[idx - 1].current?.focus();
    }
  }

  async function handleVerifyOTP(e) {
    e.preventDefault();
    const token = otp.join('');
    if (token.length !== 6) { setError('Please enter the 6-digit OTP'); return; }
    setError('');
    setLoading(true);
    try {
      await onAuth.confirmOTP(normalisedPhone, token);
      // Auth state change handled by useAuth listener
    } catch (err) {
      setError('Invalid OTP. Please check and try again.');
      setOtp(['', '', '', '', '', '']);
      otpRefs[0].current?.focus();
    } finally {
      setLoading(false);
    }
  }

  const inp = {
    height: 48, borderRadius: 10, border: '1.5px solid #e2e8f0',
    fontSize: 16, padding: '0 16px', width: '100%',
    background: '#fff', color: '#0f172a', outline: 'none',
    transition: 'border-color .15s',
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: '#f8fafc', padding: 16,
    }}>
      <div style={{
        width: '100%', maxWidth: 400,
        background: '#fff', borderRadius: 20, border: '1px solid #e2e8f0',
        padding: '40px 36px', boxShadow: '0 4px 24px rgba(0,0,0,0.06)',
      }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 32 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 12,
            background: 'linear-gradient(135deg, #1a56e8, #7c3aed)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16, fontWeight: 800, color: '#fff',
          }}>T</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 18, letterSpacing: '-0.02em' }}>TaxTalk</div>
            <div style={{ fontSize: 12, color: '#64748b' }}>RB Shah & Associates</div>
          </div>
        </div>

        {stage === STAGE.PHONE && (
          <form onSubmit={handleSendOTP}>
            <h2 style={{ fontSize: 20, fontWeight: 600, marginBottom: 6 }}>Welcome back</h2>
            <p style={{ fontSize: 14, color: '#64748b', marginBottom: 28, lineHeight: 1.5 }}>
              Enter your mobile number to receive a one-time password
            </p>

            <label style={{ fontSize: 13, fontWeight: 500, color: '#475569', display: 'block', marginBottom: 6 }}>
              Mobile number
            </label>
            <div style={{ display: 'flex', border: '1.5px solid #e2e8f0', borderRadius: 10, overflow: 'hidden', marginBottom: 16 }}>
              <div style={{ padding: '0 14px', background: '#f8fafc', borderRight: '1.5px solid #e2e8f0', display: 'flex', alignItems: 'center', fontSize: 14, color: '#475569', whiteSpace: 'nowrap' }}>
                <Phone size={15} style={{ marginRight: 6 }} /> +91
              </div>
              <input
                type="tel" inputMode="numeric" maxLength={10}
                placeholder="98765 43210"
                value={phone}
                onChange={e => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                autoFocus
                style={{ ...inp, border: 'none', borderRadius: 0, flex: 1 }}
                onFocus={e => e.target.style.borderColor = '#1a56e8'}
                onBlur={e => e.target.style.borderColor = 'transparent'}
              />
            </div>

            {error && <p style={{ fontSize: 13, color: '#dc2626', marginBottom: 12 }}>{error}</p>}

            <button type="submit" disabled={loading || phone.replace(/\D/g,'').length !== 10} style={{
              width: '100%', height: 48, borderRadius: 10,
              background: loading || phone.replace(/\D/g,'').length !== 10 ? '#94a3b8' : '#1a56e8',
              color: '#fff', fontSize: 15, fontWeight: 600, border: 'none',
              cursor: loading || phone.replace(/\D/g,'').length !== 10 ? 'not-allowed' : 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              transition: 'background .15s',
            }}>
              {loading ? 'Sending OTP…' : <><span>Send OTP</span><ArrowRight size={16} /></>}
            </button>

            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 20, padding: '10px 12px', background: '#f8fafc', borderRadius: 8 }}>
              <Shield size={14} color="#64748b" />
              <span style={{ fontSize: 12, color: '#64748b' }}>Your data is encrypted and never shared</span>
            </div>
          </form>
        )}

        {stage === STAGE.OTP && (
          <form onSubmit={handleVerifyOTP}>
            <h2 style={{ fontSize: 20, fontWeight: 600, marginBottom: 6 }}>Enter OTP</h2>
            <p style={{ fontSize: 14, color: '#64748b', marginBottom: 28 }}>
              Sent to {normalisedPhone}
            </p>

            <div style={{ display: 'flex', gap: 8, marginBottom: 20, justifyContent: 'center' }}>
              {otp.map((digit, idx) => (
                <input
                  key={idx}
                  ref={otpRefs[idx]}
                  type="text" inputMode="numeric" maxLength={1}
                  value={digit}
                  onChange={e => handleOTPChange(idx, e.target.value)}
                  onKeyDown={e => handleOTPKeyDown(idx, e)}
                  style={{
                    width: 44, height: 52, textAlign: 'center', fontSize: 20, fontWeight: 600,
                    borderRadius: 10, border: `1.5px solid ${digit ? '#1a56e8' : '#e2e8f0'}`,
                    background: digit ? '#e8f0fe' : '#fff', color: '#0f172a', outline: 'none',
                  }}
                  autoFocus={idx === 0}
                />
              ))}
            </div>

            {error && <p style={{ fontSize: 13, color: '#dc2626', marginBottom: 12, textAlign: 'center' }}>{error}</p>}

            <button type="submit" disabled={loading || otp.join('').length !== 6} style={{
              width: '100%', height: 48, borderRadius: 10,
              background: loading || otp.join('').length !== 6 ? '#94a3b8' : '#1a56e8',
              color: '#fff', fontSize: 15, fontWeight: 600, border: 'none',
              cursor: loading || otp.join('').length !== 6 ? 'not-allowed' : 'pointer',
              transition: 'background .15s',
            }}>
              {loading ? 'Verifying…' : 'Verify & continue'}
            </button>

            <button type="button" onClick={() => { setStage(STAGE.PHONE); setOtp(['','','','','','']); setError(''); }}
              style={{ width: '100%', marginTop: 10, padding: '10px', background: 'none', border: 'none', color: '#64748b', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
              <RotateCcw size={13} /> Change number
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
